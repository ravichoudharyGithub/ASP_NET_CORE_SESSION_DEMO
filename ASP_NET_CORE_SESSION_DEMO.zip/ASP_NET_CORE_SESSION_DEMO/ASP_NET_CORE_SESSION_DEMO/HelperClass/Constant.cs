﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASP_NET_CORE_SESSION_DEMO.HelperClass
{
    public static class Constants
    {
        public const string key_string = "KEY_STR";
        public const string key_int = "KEY_INT";
        public const string key_object = "KEY_OBJECT";
    }
}
